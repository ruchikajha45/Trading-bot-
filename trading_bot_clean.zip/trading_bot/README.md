# Binance Futures Testnet Trading Bot

A clean, production-structured Python CLI for placing orders on the **Binance USDT-M Futures Testnet**.  
Supports Market, Limit, and Stop-Market orders with full validation, structured logging, and clear terminal output.

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py          # Public package surface
│   ├── client.py            # Binance REST client (signing, retries, error mapping)
│   ├── orders.py            # Order placement logic (per-type functions + dispatcher)
│   ├── validators.py        # Input validation (per-field + cross-field rules)
│   └── logging_config.py   # Rotating file + console logging setup
├── cli.py                   # CLI entry point (argparse, subcommands, output formatting)
├── logs/
│   └── trading_bot.log      # Rotating log file (created at first run)
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Get Testnet Credentials

1. Go to [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Log in with your GitHub account
3. Navigate to **API Management** and generate a key pair
4. Copy your **API Key** and **Secret Key**

### 2. Clone / Download

```bash
git clone https://github.com/your-username/trading-bot.git
cd trading-bot
```

### 3. Create a Virtual Environment

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

### 5. Set Credentials

```bash
# Recommended: environment variables (never commit keys to source control)
export BINANCE_API_KEY="your_api_key_here"
export BINANCE_API_SECRET="your_api_secret_here"
```

Or pass them inline per command (see examples below).

---

## How to Run

### Check Connectivity

```bash
python cli.py ping
```

### View Account Balance

```bash
python cli.py account
```

### Place a Market BUY Order

```bash
python cli.py place --symbol BTCUSDT --side BUY --type MARKET --qty 0.001
```

### Place a Limit SELL Order

```bash
python cli.py place --symbol BTCUSDT --side SELL --type LIMIT --qty 0.001 --price 99000
```

### Place a Stop-Market BUY Order (Bonus Order Type)

Triggers a market buy when price drops to 95,000 USDT:

```bash
python cli.py place --symbol BTCUSDT --side BUY --type STOP_MARKET --qty 0.001 --stop-price 95000
```

### List Open Orders

```bash
python cli.py orders
python cli.py orders --symbol BTCUSDT    # filter by symbol
```

### Cancel an Order

```bash
python cli.py cancel --symbol BTCUSDT --order-id 4111524101
```

### See Raw JSON Response

Append `--json` to any `place` command:

```bash
python cli.py place --symbol ETHUSDT --side BUY --type MARKET --qty 0.01 --json
```

### Pass Credentials Inline (no env vars)

```bash
python cli.py --api-key YOUR_KEY --api-secret YOUR_SECRET place \
  --symbol BTCUSDT --side BUY --type MARKET --qty 0.001
```

### Increase Log Verbosity

```bash
python cli.py --log-level DEBUG place --symbol BTCUSDT --side BUY --type MARKET --qty 0.001
```

---

## Example Terminal Output

```
Order Request Summary
  Symbol     : BTCUSDT
  Side       : BUY
  Type       : MARKET
  Quantity   : 0.001
  Price      : N/A (market)
  Stop Price : N/A

ℹ  Submitting order to Binance Futures Testnet…

┌─ Order Response ──────────────────────────────────────┐
  Order ID      : 4111523894
  Client ID     : x-abc123
  Symbol        : BTCUSDT
  Side          : BUY
  Type          : MARKET
  Status        : FILLED
  Quantity      : 0.001
  Executed Qty  : 0.001
  Avg Price     : 97450.50
  Price         : 0
  Stop Price    : 0
  Time in Force : GTC
  Reduce Only   : False
  Update Time   : 1736950926001
└───────────────────────────────────────────────────────┘

✔  Order placed successfully — orderId=4111523894 status=FILLED
```

---

## Logging

All requests, responses, and errors are written to `logs/trading_bot.log` (DEBUG level).  
Console output mirrors INFO level by default.

Log format:
```
2025-01-15 14:22:05 | INFO     | trading_bot.orders           | MARKET order — symbol=BTCUSDT side=BUY qty=0.001
```

Logs rotate automatically at 5 MB with 3 backup files kept.

---

## Order Types Supported

| Type          | Description                                    | Required Flags               |
|---------------|------------------------------------------------|------------------------------|
| `MARKET`      | Executes immediately at best available price   | `--qty`                      |
| `LIMIT`       | Executes at specified price or better (GTC)    | `--qty`, `--price`           |
| `STOP_MARKET` | Market order triggered at stop price           | `--qty`, `--stop-price`      |

---

## Validation Rules

- **Symbol**: Must be uppercase alphanumeric and end with `USDT`
- **Side**: Must be `BUY` or `SELL`
- **Type**: Must be `MARKET`, `LIMIT`, or `STOP_MARKET`
- **Quantity**: Must be a positive number ≥ 0.001
- **Price**: Required for `LIMIT`; ignored (with a warning) for `MARKET`
- **Stop Price**: Required for `STOP_MARKET`

Validation errors are shown clearly before any API call is made.

---

## Error Handling

| Scenario                       | Behaviour                                               |
|--------------------------------|---------------------------------------------------------|
| Invalid user input             | `ValidationError` — descriptive message, no API call    |
| Binance API rejection          | `BinanceAPIError` — code + message from Binance         |
| Network timeout / unreachable  | `BinanceNetworkError` — connection details logged       |
| Unexpected HTTP status         | `BinanceHTTPError` — status + body excerpt logged       |

All errors set exit code `1`; successful commands exit `0`.

---

## Assumptions

- Only **USDT-M perpetual futures** are targeted (symbols must end in `USDT`).
- Limit orders use `timeInForce=GTC` (Good Till Cancelled) by default.
- The testnet base URL is `https://testnet.binancefuture.com` — configurable via `--base-url` or `BINANCE_BASE_URL`.
- No position-sizing or leverage management is performed; the bot is a pure order-placement tool.
- Credentials are **never** logged or printed to console.

---

## Dependencies

```
requests>=2.31.0   # HTTP client with retry support
urllib3>=2.0.0     # HTTP connection pooling (transitive, pinned for security)
```

Only stdlib + `requests`. No `python-binance` or other heavyweight SDK required.

---

## Running Tests (optional)

```bash
# Quick smoke test — place one of each order type and check exit codes
export BINANCE_API_KEY="..."
export BINANCE_API_SECRET="..."

python cli.py ping
python cli.py account
python cli.py place --symbol BTCUSDT --side BUY  --type MARKET     --qty 0.001
python cli.py place --symbol BTCUSDT --side SELL --type LIMIT       --qty 0.001 --price 99000
python cli.py place --symbol BTCUSDT --side BUY  --type STOP_MARKET --qty 0.001 --stop-price 95000
python cli.py orders --symbol BTCUSDT
```
