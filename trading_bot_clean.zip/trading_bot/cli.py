#!/usr/bin/env python3
"""
cli.py — Command-line entry point for the Binance Futures Testnet Trading Bot.

Usage examples
--------------
# Market BUY
python cli.py place --symbol BTCUSDT --side BUY --type MARKET --qty 0.001

# Limit SELL
python cli.py place --symbol ETHUSDT --side SELL --type LIMIT --qty 0.01 --price 3800

# Stop-Market BUY (bonus order type)
python cli.py place --symbol BTCUSDT --side BUY --type STOP_MARKET --qty 0.001 --stop-price 95000

# Check account balance
python cli.py account

# List open orders
python cli.py orders --symbol BTCUSDT

# Cancel an order
python cli.py cancel --symbol BTCUSDT --order-id 12345678

# Ping the testnet
python cli.py ping
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Optional

# ── Bootstrap logging before importing anything else ─────────────────────────
from bot.logging_config import setup_logging

log = setup_logging(log_level=os.getenv("LOG_LEVEL", "INFO"))

from bot import (  # noqa: E402 — must come after setup_logging
    BinanceFuturesClient,
    BinanceAPIError,
    BinanceNetworkError,
    OrderError,
    ValidationError,
    format_order_response,
    get_logger,
    place_order,
    validate_order_params,
)

log = get_logger("cli")

# ── ANSI colour helpers ───────────────────────────────────────────────────────

GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"


def ok(msg: str) -> None:
    print(f"{GREEN}{BOLD}✔  {msg}{RESET}")


def err(msg: str) -> None:
    print(f"{RED}{BOLD}✖  {msg}{RESET}", file=sys.stderr)


def info(msg: str) -> None:
    print(f"{CYAN}ℹ  {msg}{RESET}")


def warn(msg: str) -> None:
    print(f"{YELLOW}⚠  {msg}{RESET}")


# ── Client factory ────────────────────────────────────────────────────────────


def _build_client(args: argparse.Namespace) -> BinanceFuturesClient:
    """
    Resolve API credentials from CLI flags → env vars → exit with an error.
    """
    api_key    = getattr(args, "api_key", None)    or os.getenv("BINANCE_API_KEY")
    api_secret = getattr(args, "api_secret", None) or os.getenv("BINANCE_API_SECRET")
    base_url   = getattr(args, "base_url", None)   or os.getenv(
        "BINANCE_BASE_URL", "https://testnet.binancefuture.com"
    )

    if not api_key or not api_secret:
        err(
            "API credentials are missing.\n"
            "  Set BINANCE_API_KEY and BINANCE_API_SECRET environment variables, or\n"
            "  pass --api-key and --api-secret on the command line."
        )
        sys.exit(1)

    return BinanceFuturesClient(
        api_key=api_key,
        api_secret=api_secret,
        base_url=base_url,
    )


# ── Subcommand handlers ───────────────────────────────────────────────────────


def cmd_ping(client: BinanceFuturesClient, _args: argparse.Namespace) -> int:
    """Ping the testnet and report connectivity."""
    info("Pinging Binance Futures Testnet…")
    if client.ping():
        ok("Testnet is reachable.")
        return 0
    else:
        err("Testnet is NOT reachable. Check your network.")
        return 1


def cmd_account(client: BinanceFuturesClient, _args: argparse.Namespace) -> int:
    """Display account summary (available balance, unrealised PnL)."""
    info("Fetching account information…")
    try:
        account = client.get_account()
    except (BinanceAPIError, BinanceNetworkError) as exc:
        err(f"Failed to fetch account: {exc}")
        log.error("Account fetch failed: %s", exc)
        return 1

    total_balance = account.get("totalWalletBalance", "N/A")
    available     = account.get("availableBalance", "N/A")
    unrealised    = account.get("totalUnrealizedProfit", "N/A")
    margin_ratio  = account.get("totalMaintMargin", "N/A")

    print(
        f"\n{BOLD}Account Summary{RESET}\n"
        f"  Total Wallet Balance  : {CYAN}{total_balance} USDT{RESET}\n"
        f"  Available Balance     : {CYAN}{available} USDT{RESET}\n"
        f"  Unrealised PnL        : {CYAN}{unrealised} USDT{RESET}\n"
        f"  Maint. Margin         : {CYAN}{margin_ratio} USDT{RESET}\n"
    )
    log.info(
        "Account summary — balance=%s available=%s unrealised=%s",
        total_balance, available, unrealised,
    )
    return 0


def cmd_orders(client: BinanceFuturesClient, args: argparse.Namespace) -> int:
    """List open orders, optionally filtered by symbol."""
    symbol = getattr(args, "symbol", None)
    info(f"Fetching open orders{' for ' + symbol if symbol else ''}…")
    try:
        orders = client.get_open_orders(symbol=symbol)
    except (BinanceAPIError, BinanceNetworkError) as exc:
        err(f"Failed to fetch open orders: {exc}")
        log.error("Open orders fetch failed: %s", exc)
        return 1

    if not orders:
        info("No open orders found.")
        return 0

    print(f"\n{BOLD}Open Orders ({len(orders)}){RESET}")
    for o in orders:
        print(
            f"  [{o.get('orderId')}] {o.get('symbol')} "
            f"{o.get('side')} {o.get('type')} "
            f"qty={o.get('origQty')} price={o.get('price')} "
            f"status={o.get('status')}"
        )
    print()
    log.info("Listed %d open order(s)", len(orders))
    return 0


def cmd_cancel(client: BinanceFuturesClient, args: argparse.Namespace) -> int:
    """Cancel an open order by orderId."""
    symbol   = args.symbol.upper()
    order_id = args.order_id

    info(f"Cancelling order {order_id} on {symbol}…")
    try:
        resp = client.cancel_order(symbol=symbol, order_id=order_id)
    except (BinanceAPIError, BinanceNetworkError) as exc:
        err(f"Failed to cancel order: {exc}")
        log.error("Cancel failed — symbol=%s orderId=%s error=%s", symbol, order_id, exc)
        return 1

    ok(f"Order {resp.get('orderId')} cancelled — status: {resp.get('status')}")
    log.info("Order cancelled: %s", resp)
    return 0


def cmd_place(client: BinanceFuturesClient, args: argparse.Namespace) -> int:
    """Validate inputs, print a request summary, place the order, print the result."""

    # ── 1. Validate ───────────────────────────────────────────────────────────
    try:
        params = validate_order_params(
            symbol=args.symbol,
            side=args.side,
            order_type=args.type,
            quantity=args.qty,
            price=getattr(args, "price", None),
            stop_price=getattr(args, "stop_price", None),
        )
    except ValidationError as exc:
        err(f"Validation error: {exc}")
        log.error("Validation failed: %s", exc)
        return 1

    # ── 2. Print request summary ──────────────────────────────────────────────
    price_display = f"{params['price']}" if params["price"] else "N/A (market)"
    stop_display  = f"{params['stop_price']}" if params["stop_price"] else "N/A"

    print(
        f"\n{BOLD}Order Request Summary{RESET}\n"
        f"  Symbol     : {CYAN}{params['symbol']}{RESET}\n"
        f"  Side       : {CYAN}{params['side']}{RESET}\n"
        f"  Type       : {CYAN}{params['order_type']}{RESET}\n"
        f"  Quantity   : {CYAN}{params['quantity']}{RESET}\n"
        f"  Price      : {CYAN}{price_display}{RESET}\n"
        f"  Stop Price : {CYAN}{stop_display}{RESET}\n"
    )

    # ── 3. Place the order ────────────────────────────────────────────────────
    info("Submitting order to Binance Futures Testnet…")
    try:
        response = place_order(
            client=client,
            symbol=params["symbol"],
            side=params["side"],
            order_type=params["order_type"],
            quantity=params["quantity"],
            price=params["price"],
            stop_price=params["stop_price"],
        )
    except OrderError as exc:
        err(f"Order failed: {exc}")
        log.error("Order placement failed: %s", exc)
        return 1
    except ValueError as exc:
        err(f"Order configuration error: {exc}")
        log.error("Order configuration error: %s", exc)
        return 1

    # ── 4. Print the response ─────────────────────────────────────────────────
    print(format_order_response(response))
    ok(
        f"Order placed successfully — "
        f"orderId={response.get('orderId')} "
        f"status={response.get('status')}"
    )

    if args.json:
        print("\nRaw JSON response:")
        print(json.dumps(response, indent=2))

    return 0


# ── Argument parser ───────────────────────────────────────────────────────────


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description=(
            "Binance USDT-M Futures Testnet Trading Bot\n"
            "Credentials: set BINANCE_API_KEY and BINANCE_API_SECRET env vars,\n"
            "or pass --api-key / --api-secret."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # ── Global flags ──────────────────────────────────────────────────────────
    parser.add_argument("--api-key",    metavar="KEY",    help="Binance API key")
    parser.add_argument("--api-secret", metavar="SECRET", help="Binance API secret")
    parser.add_argument(
        "--base-url",
        metavar="URL",
        default="https://testnet.binancefuture.com",
        help="Testnet base URL (default: https://testnet.binancefuture.com)",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Console log verbosity (default: INFO; file always gets DEBUG)",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── ping ──────────────────────────────────────────────────────────────────
    subparsers.add_parser("ping", help="Check testnet connectivity")

    # ── account ───────────────────────────────────────────────────────────────
    subparsers.add_parser("account", help="Show account balance summary")

    # ── orders ────────────────────────────────────────────────────────────────
    orders_p = subparsers.add_parser("orders", help="List open orders")
    orders_p.add_argument("--symbol", metavar="SYMBOL", help="Filter by trading pair")

    # ── cancel ────────────────────────────────────────────────────────────────
    cancel_p = subparsers.add_parser("cancel", help="Cancel an open order")
    cancel_p.add_argument("--symbol",   required=True, metavar="SYMBOL")
    cancel_p.add_argument("--order-id", required=True, type=int, dest="order_id")

    # ── place ─────────────────────────────────────────────────────────────────
    place_p = subparsers.add_parser(
        "place",
        help="Place a new order (MARKET / LIMIT / STOP_MARKET)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "Place Order Examples\n"
            "--------------------\n"
            "  Market BUY  : python cli.py place --symbol BTCUSDT --side BUY --type MARKET --qty 0.001\n"
            "  Limit SELL  : python cli.py place --symbol ETHUSDT --side SELL --type LIMIT --qty 0.01 --price 3800\n"
            "  Stop-Market : python cli.py place --symbol BTCUSDT --side BUY --type STOP_MARKET --qty 0.001 --stop-price 95000\n"
        ),
    )
    place_p.add_argument("--symbol", required=True, metavar="SYMBOL",
                         help="Trading pair, e.g. BTCUSDT")
    place_p.add_argument("--side",   required=True, choices=["BUY", "SELL"],
                         help="BUY or SELL")
    place_p.add_argument("--type",   required=True,
                         choices=["MARKET", "LIMIT", "STOP_MARKET"],
                         dest="type",
                         help="Order type")
    place_p.add_argument("--qty",    required=True, type=float,
                         help="Order quantity (number of contracts)")
    place_p.add_argument("--price",  type=float, default=None,
                         help="Limit price in USDT (required for LIMIT orders)")
    place_p.add_argument("--stop-price", type=float, default=None, dest="stop_price",
                         help="Stop trigger price in USDT (required for STOP_MARKET)")
    place_p.add_argument("--json",   action="store_true",
                         help="Also print the raw JSON response")

    return parser


# ── Main ──────────────────────────────────────────────────────────────────────


def main() -> None:
    parser = _build_parser()
    args   = parser.parse_args()

    # Re-initialise logging with the user-requested level
    setup_logging(log_level=args.log_level)
    log = get_logger("cli")
    log.debug("Parsed args: %s", vars(args))

    client = _build_client(args)

    # Dispatch to subcommand handler
    handlers = {
        "ping":    cmd_ping,
        "account": cmd_account,
        "orders":  cmd_orders,
        "cancel":  cmd_cancel,
        "place":   cmd_place,
    }

    handler = handlers.get(args.command)
    if handler is None:
        err(f"Unknown command: {args.command}")
        parser.print_help()
        sys.exit(1)

    exit_code = handler(client, args)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
