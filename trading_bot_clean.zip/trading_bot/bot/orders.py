"""
Order placement logic for Binance USDT-M Futures.

Provides:
- place_market_order
- place_limit_order
- place_stop_market_order  (bonus third order type)
- place_order              (unified dispatcher)
- format_order_response    (human-readable summary builder)

All functions log the request summary and the full Binance response, and map
any exceptions to a consistent OrderError for the CLI layer to handle.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Optional

from .client import BinanceFuturesClient, BinanceAPIError, BinanceNetworkError, BinanceHTTPError
from .logging_config import get_logger

log = get_logger("orders")

ORDER_ENDPOINT = "/fapi/v1/order"


# ── Exceptions ────────────────────────────────────────────────────────────────


class OrderError(Exception):
    """Raised when an order placement attempt fails."""


# ── Internal helpers ──────────────────────────────────────────────────────────


def _decimal_to_str(value: Optional[Decimal]) -> Optional[str]:
    """Convert a Decimal to a clean string (no scientific notation)."""
    if value is None:
        return None
    return format(value, "f")


def _place(client: BinanceFuturesClient, params: dict) -> dict:
    """
    Send an order POST request and translate exceptions into OrderError.
    Also logs the full request summary and the response.
    """
    log.info("Placing order — params=%s", params)
    try:
        response = client.post(ORDER_ENDPOINT, params=params)
    except BinanceAPIError as exc:
        log.error("Binance API rejected the order: code=%s msg=%s", exc.code, exc.msg)
        raise OrderError(f"Binance API error {exc.code}: {exc.msg}") from exc
    except BinanceNetworkError as exc:
        log.error("Network failure while placing order: %s", exc)
        raise OrderError(f"Network error: {exc}") from exc
    except BinanceHTTPError as exc:
        log.error("HTTP error while placing order: %s", exc)
        raise OrderError(f"HTTP error: {exc}") from exc

    log.info(
        "Order accepted — orderId=%s symbol=%s status=%s executedQty=%s",
        response.get("orderId"),
        response.get("symbol"),
        response.get("status"),
        response.get("executedQty"),
    )
    log.debug("Full order response: %s", response)
    return response


# ── Public API ────────────────────────────────────────────────────────────────


def place_market_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    quantity: Decimal,
) -> dict:
    """
    Place a MARKET order on Binance USDT-M Futures.

    Args:
        client:   Authenticated BinanceFuturesClient.
        symbol:   Trading pair (e.g. 'BTCUSDT').
        side:     'BUY' or 'SELL'.
        quantity: Number of contracts to trade.

    Returns:
        Raw Binance order response dict.

    Raises:
        OrderError: On API, network, or HTTP failures.
    """
    params = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "quantity": _decimal_to_str(quantity),
    }
    log.info(
        "MARKET order — symbol=%s side=%s qty=%s",
        symbol, side, quantity,
    )
    return _place(client, params)


def place_limit_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    quantity: Decimal,
    price: Decimal,
    time_in_force: str = "GTC",
) -> dict:
    """
    Place a LIMIT order on Binance USDT-M Futures.

    Args:
        client:        Authenticated BinanceFuturesClient.
        symbol:        Trading pair (e.g. 'BTCUSDT').
        side:          'BUY' or 'SELL'.
        quantity:      Number of contracts to trade.
        price:         Limit price in USDT.
        time_in_force: 'GTC' (default), 'IOC', or 'FOK'.

    Returns:
        Raw Binance order response dict.

    Raises:
        OrderError: On API, network, or HTTP failures.
    """
    params = {
        "symbol": symbol,
        "side": side,
        "type": "LIMIT",
        "quantity": _decimal_to_str(quantity),
        "price": _decimal_to_str(price),
        "timeInForce": time_in_force,
    }
    log.info(
        "LIMIT order — symbol=%s side=%s qty=%s price=%s tif=%s",
        symbol, side, quantity, price, time_in_force,
    )
    return _place(client, params)


def place_stop_market_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    quantity: Decimal,
    stop_price: Decimal,
) -> dict:
    """
    Place a STOP_MARKET order on Binance USDT-M Futures.

    This is the bonus third order type.  A stop-market order becomes a
    market order once the stop price is touched.

    Args:
        client:     Authenticated BinanceFuturesClient.
        symbol:     Trading pair (e.g. 'BTCUSDT').
        side:       'BUY' or 'SELL'.
        quantity:   Number of contracts to trade.
        stop_price: Trigger price in USDT.

    Returns:
        Raw Binance order response dict.

    Raises:
        OrderError: On API, network, or HTTP failures.
    """
    params = {
        "symbol": symbol,
        "side": side,
        "type": "STOP_MARKET",
        "quantity": _decimal_to_str(quantity),
        "stopPrice": _decimal_to_str(stop_price),
    }
    log.info(
        "STOP_MARKET order — symbol=%s side=%s qty=%s stopPrice=%s",
        symbol, side, quantity, stop_price,
    )
    return _place(client, params)


def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: Decimal,
    price: Optional[Decimal] = None,
    stop_price: Optional[Decimal] = None,
) -> dict:
    """
    Unified order dispatcher.  Delegates to the appropriate typed function.

    Args:
        client:     Authenticated BinanceFuturesClient.
        symbol:     Trading pair.
        side:       'BUY' or 'SELL'.
        order_type: 'MARKET', 'LIMIT', or 'STOP_MARKET'.
        quantity:   Size.
        price:      Required for LIMIT orders.
        stop_price: Required for STOP_MARKET orders.

    Returns:
        Raw Binance order response dict.

    Raises:
        OrderError:      On API, network, or HTTP failures.
        ValueError:      On unsupported order_type.
    """
    if order_type == "MARKET":
        return place_market_order(client, symbol, side, quantity)
    elif order_type == "LIMIT":
        if price is None:
            raise ValueError("price is required for LIMIT orders")
        return place_limit_order(client, symbol, side, quantity, price)
    elif order_type == "STOP_MARKET":
        if stop_price is None:
            raise ValueError("stop_price is required for STOP_MARKET orders")
        return place_stop_market_order(client, symbol, side, quantity, stop_price)
    else:
        raise ValueError(f"Unsupported order type: {order_type!r}")


# ── Formatting ────────────────────────────────────────────────────────────────


def format_order_response(response: dict) -> str:
    """
    Build a human-readable summary of a Binance order response.

    Extracts the most useful fields and formats them for console output.
    Gracefully handles missing fields (testnet responses may vary).
    """
    lines = [
        "",
        "┌─ Order Response ──────────────────────────────────────┐",
        f"  Order ID      : {response.get('orderId', 'N/A')}",
        f"  Client ID     : {response.get('clientOrderId', 'N/A')}",
        f"  Symbol        : {response.get('symbol', 'N/A')}",
        f"  Side          : {response.get('side', 'N/A')}",
        f"  Type          : {response.get('type', 'N/A')}",
        f"  Status        : {response.get('status', 'N/A')}",
        f"  Quantity      : {response.get('origQty', 'N/A')}",
        f"  Executed Qty  : {response.get('executedQty', 'N/A')}",
        f"  Avg Price     : {response.get('avgPrice', 'N/A')}",
        f"  Price         : {response.get('price', 'N/A')}",
        f"  Stop Price    : {response.get('stopPrice', 'N/A')}",
        f"  Time in Force : {response.get('timeInForce', 'N/A')}",
        f"  Reduce Only   : {response.get('reduceOnly', 'N/A')}",
        f"  Update Time   : {response.get('updateTime', 'N/A')}",
        "└───────────────────────────────────────────────────────┘",
        "",
    ]
    return "\n".join(lines)
