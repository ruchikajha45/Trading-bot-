"""
Input validation for the Binance Futures Trading Bot.
All user-supplied parameters are validated here before reaching the API layer.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Optional

from .logging_config import get_logger

log = get_logger("validators")

# ── Constants ─────────────────────────────────────────────────────────────────

VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_MARKET"}

# Binance Futures minimum notional is $5 USDT; we enforce a sensible minimum qty
MIN_QUANTITY = Decimal("0.001")


# ── Exceptions ────────────────────────────────────────────────────────────────


class ValidationError(ValueError):
    """Raised when user-supplied input fails validation."""


# ── Validators ────────────────────────────────────────────────────────────────


def validate_symbol(symbol: str) -> str:
    """
    Validate and normalise a trading pair symbol.

    Rules:
    - Non-empty string
    - Uppercase letters and digits only
    - Must end with 'USDT' (USDT-M perpetuals only)

    Returns the uppercased symbol on success.
    Raises ValidationError on failure.
    """
    if not symbol or not isinstance(symbol, str):
        raise ValidationError("Symbol must be a non-empty string.")
    symbol = symbol.strip().upper()
    if not symbol.isalnum():
        raise ValidationError(
            f"Symbol '{symbol}' contains invalid characters. "
            "Use only letters and digits (e.g. BTCUSDT)."
        )
    if not symbol.endswith("USDT"):
        raise ValidationError(
            f"Symbol '{symbol}' does not end with 'USDT'. "
            "Only USDT-M perpetual contracts are supported."
        )
    log.debug("Symbol validated: %s", symbol)
    return symbol


def validate_side(side: str) -> str:
    """
    Validate order side.

    Accepts 'BUY' or 'SELL' (case-insensitive).
    Raises ValidationError for any other value.
    """
    if not side or not isinstance(side, str):
        raise ValidationError("Side must be a non-empty string.")
    side = side.strip().upper()
    if side not in VALID_SIDES:
        raise ValidationError(
            f"Invalid side '{side}'. Must be one of: {', '.join(sorted(VALID_SIDES))}."
        )
    log.debug("Side validated: %s", side)
    return side


def validate_order_type(order_type: str) -> str:
    """
    Validate order type.

    Accepts MARKET, LIMIT, or STOP_MARKET (case-insensitive).
    Raises ValidationError otherwise.
    """
    if not order_type or not isinstance(order_type, str):
        raise ValidationError("Order type must be a non-empty string.")
    order_type = order_type.strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise ValidationError(
            f"Invalid order type '{order_type}'. "
            f"Must be one of: {', '.join(sorted(VALID_ORDER_TYPES))}."
        )
    log.debug("Order type validated: %s", order_type)
    return order_type


def validate_quantity(quantity: str | float | Decimal) -> Decimal:
    """
    Validate and parse the order quantity.

    - Must be a positive number greater than MIN_QUANTITY.
    - Returned as a Decimal for precision.
    Raises ValidationError on failure.
    """
    try:
        qty = Decimal(str(quantity))
    except (InvalidOperation, TypeError):
        raise ValidationError(
            f"Quantity '{quantity}' is not a valid number."
        )
    if qty <= 0:
        raise ValidationError(
            f"Quantity must be positive, got {qty}."
        )
    if qty < MIN_QUANTITY:
        raise ValidationError(
            f"Quantity {qty} is below the minimum allowed ({MIN_QUANTITY})."
        )
    log.debug("Quantity validated: %s", qty)
    return qty


def validate_price(price: Optional[str | float | Decimal]) -> Optional[Decimal]:
    """
    Validate and parse the limit price.

    - None is allowed (for MARKET orders).
    - When provided, must be a positive number.
    - Returned as a Decimal for precision.
    Raises ValidationError on failure.
    """
    if price is None:
        return None
    try:
        p = Decimal(str(price))
    except (InvalidOperation, TypeError):
        raise ValidationError(
            f"Price '{price}' is not a valid number."
        )
    if p <= 0:
        raise ValidationError(
            f"Price must be positive, got {p}."
        )
    log.debug("Price validated: %s", p)
    return p


def validate_stop_price(stop_price: Optional[str | float | Decimal]) -> Optional[Decimal]:
    """Validate stop price (used for STOP_MARKET orders)."""
    if stop_price is None:
        return None
    try:
        sp = Decimal(str(stop_price))
    except (InvalidOperation, TypeError):
        raise ValidationError(
            f"Stop price '{stop_price}' is not a valid number."
        )
    if sp <= 0:
        raise ValidationError(f"Stop price must be positive, got {sp}.")
    log.debug("Stop price validated: %s", sp)
    return sp


def validate_order_params(
    symbol: str,
    side: str,
    order_type: str,
    quantity: str | float | Decimal,
    price: Optional[str | float | Decimal] = None,
    stop_price: Optional[str | float | Decimal] = None,
) -> dict:
    """
    Run all field-level validations and cross-field business rules.

    Returns a dict of cleaned, validated parameters.
    Raises ValidationError with a descriptive message on the first failure.
    """
    cleaned = {
        "symbol": validate_symbol(symbol),
        "side": validate_side(side),
        "order_type": validate_order_type(order_type),
        "quantity": validate_quantity(quantity),
        "price": validate_price(price),
        "stop_price": validate_stop_price(stop_price),
    }

    # Cross-field rules
    ot = cleaned["order_type"]

    if ot == "LIMIT" and cleaned["price"] is None:
        raise ValidationError(
            "A price is required for LIMIT orders. "
            "Supply it with --price."
        )

    if ot == "STOP_MARKET" and cleaned["stop_price"] is None:
        raise ValidationError(
            "A stop price is required for STOP_MARKET orders. "
            "Supply it with --stop-price."
        )

    if ot == "MARKET" and cleaned["price"] is not None:
        log.warning(
            "Price was supplied for a MARKET order and will be ignored."
        )
        cleaned["price"] = None

    log.info(
        "Order params validated — symbol=%s side=%s type=%s qty=%s price=%s stop=%s",
        cleaned["symbol"],
        cleaned["side"],
        cleaned["order_type"],
        cleaned["quantity"],
        cleaned["price"],
        cleaned["stop_price"],
    )
    return cleaned
