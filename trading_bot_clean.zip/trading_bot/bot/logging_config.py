"""
Logging configuration for the Binance Futures Trading Bot.
Sets up dual-output logging: structured file logs + human-readable console output.
"""

import logging
import logging.handlers
import sys
from pathlib import Path


LOG_DIR = Path("logs")
LOG_FILE = LOG_DIR / "trading_bot.log"
LOG_FORMAT_FILE = "%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s"
LOG_FORMAT_CONSOLE = "%(levelname)-8s │ %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logging(log_level: str = "INFO") -> logging.Logger:
    """
    Configure and return the root logger for the trading bot.

    Sets up:
    - Rotating file handler  → logs/trading_bot.log  (DEBUG and above)
    - Console (stderr) handler → INFO and above, compact format

    Args:
        log_level: Minimum level for console output ('DEBUG', 'INFO', 'WARNING', …)

    Returns:
        The configured 'trading_bot' logger instance.
    """
    LOG_DIR.mkdir(exist_ok=True)

    logger = logging.getLogger("trading_bot")
    logger.setLevel(logging.DEBUG)

    # Avoid duplicate handlers if setup_logging is called more than once
    if logger.handlers:
        return logger

    # ── File handler (rotating, 5 MB × 3 backups) ────────────────────────────
    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE,
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(LOG_FORMAT_FILE, datefmt=DATE_FORMAT))

    # ── Console handler ───────────────────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    console_handler.setFormatter(logging.Formatter(LOG_FORMAT_CONSOLE))

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


def get_logger(name: str) -> logging.Logger:
    """Return a child logger under the 'trading_bot' namespace."""
    return logging.getLogger(f"trading_bot.{name}")
