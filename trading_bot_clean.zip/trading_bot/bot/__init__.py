"""
trading_bot.bot — core library package.

Public surface:
    BinanceFuturesClient   – authenticated REST client
    place_order            – unified order dispatcher
    format_order_response  – response formatter
    validate_order_params  – input validation
    setup_logging          – logging initialiser
    OrderError             – order-level exception
    ValidationError        – validation-level exception
    BinanceAPIError        – Binance API-level exception
"""

from .client import BinanceFuturesClient, BinanceAPIError, BinanceNetworkError, BinanceHTTPError
from .orders import place_order, format_order_response, OrderError
from .validators import validate_order_params, ValidationError
from .logging_config import setup_logging, get_logger

__all__ = [
    "BinanceFuturesClient",
    "BinanceAPIError",
    "BinanceNetworkError",
    "BinanceHTTPError",
    "place_order",
    "format_order_response",
    "OrderError",
    "validate_order_params",
    "ValidationError",
    "setup_logging",
    "get_logger",
]
