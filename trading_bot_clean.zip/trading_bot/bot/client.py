"""
Binance Futures Testnet REST API client.

Handles:
- HMAC-SHA256 request signing
- Timestamp synchronisation
- HTTP session management (connection pooling via requests.Session)
- Structured logging of every request and response
- Granular exception mapping (network errors, HTTP errors, Binance API errors)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any, Optional
from urllib.parse import urlencode

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .logging_config import get_logger

log = get_logger("client")

# ── Defaults ──────────────────────────────────────────────────────────────────

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
DEFAULT_RECV_WINDOW = 5_000        # milliseconds
REQUEST_TIMEOUT = 10               # seconds


# ── Exceptions ────────────────────────────────────────────────────────────────


class BinanceClientError(Exception):
    """Base exception for all client-layer errors."""


class BinanceAPIError(BinanceClientError):
    """Raised when Binance returns a non-zero error code in its JSON body."""

    def __init__(self, code: int, msg: str) -> None:
        self.code = code
        self.msg = msg
        super().__init__(f"Binance API error {code}: {msg}")


class BinanceNetworkError(BinanceClientError):
    """Raised on connection timeouts or network-level failures."""


class BinanceHTTPError(BinanceClientError):
    """Raised when Binance returns an unexpected HTTP status code."""


# ── Client ────────────────────────────────────────────────────────────────────


class BinanceFuturesClient:
    """
    Lightweight Binance USDT-M Futures REST client.

    Usage::

        client = BinanceFuturesClient(api_key="...", api_secret="...")
        resp = client.get("/fapi/v1/ping")
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = TESTNET_BASE_URL,
        recv_window: int = DEFAULT_RECV_WINDOW,
    ) -> None:
        if not api_key or not api_secret:
            raise BinanceClientError(
                "API key and secret must be non-empty strings."
            )
        self._api_key = api_key
        self._api_secret = api_secret
        self.base_url = base_url.rstrip("/")
        self.recv_window = recv_window
        self._session = self._build_session()
        log.info(
            "BinanceFuturesClient initialised — base_url=%s recv_window=%s ms",
            self.base_url,
            self.recv_window,
        )

    # ── Internal helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _build_session() -> requests.Session:
        """Return a requests.Session with an automatic retry policy."""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "DELETE"],
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session

    def _sign(self, params: dict) -> str:
        """Return the HMAC-SHA256 signature for the given parameter dict."""
        query_string = urlencode(params)
        return hmac.new(
            self._api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _headers(self) -> dict:
        return {
            "X-MBX-APIKEY": self._api_key,
            "Content-Type": "application/x-www-form-urlencoded",
        }

    @staticmethod
    def _timestamp() -> int:
        return int(time.time() * 1000)

    def _handle_response(self, response: requests.Response) -> Any:
        """
        Parse a Binance HTTP response.

        - Raises BinanceAPIError for Binance-level errors (non-zero 'code' field).
        - Raises BinanceHTTPError for unexpected HTTP status codes.
        - Returns the parsed JSON body on success.
        """
        log.debug(
            "HTTP %s %s — status=%s body=%s",
            response.request.method,
            response.url,
            response.status_code,
            response.text[:500],
        )

        try:
            body = response.json()
        except ValueError:
            body = response.text

        if isinstance(body, dict) and "code" in body and body["code"] != 200:
            # Binance error envelope: {"code": -XXXX, "msg": "..."}
            raise BinanceAPIError(code=body["code"], msg=body.get("msg", "unknown"))

        if not response.ok:
            raise BinanceHTTPError(
                f"HTTP {response.status_code} from {response.url}: {response.text[:300]}"
            )

        return body

    # ── Public methods ────────────────────────────────────────────────────────

    def get(self, path: str, params: Optional[dict] = None, signed: bool = False) -> Any:
        """Send a signed or unsigned GET request."""
        params = params or {}
        if signed:
            params["timestamp"] = self._timestamp()
            params["recvWindow"] = self.recv_window
            params["signature"] = self._sign(params)

        url = f"{self.base_url}{path}"
        log.info("GET %s params=%s", url, {k: v for k, v in params.items() if k != "signature"})
        try:
            resp = self._session.get(
                url, params=params, headers=self._headers(), timeout=REQUEST_TIMEOUT
            )
        except requests.exceptions.Timeout as exc:
            log.error("GET %s timed out: %s", url, exc)
            raise BinanceNetworkError(f"Request timed out: {exc}") from exc
        except requests.exceptions.ConnectionError as exc:
            log.error("GET %s connection error: %s", url, exc)
            raise BinanceNetworkError(f"Connection error: {exc}") from exc

        return self._handle_response(resp)

    def post(self, path: str, params: Optional[dict] = None) -> Any:
        """Send a signed POST request (always signed for order endpoints)."""
        params = params or {}
        params["timestamp"] = self._timestamp()
        params["recvWindow"] = self.recv_window
        params["signature"] = self._sign(params)

        url = f"{self.base_url}{path}"
        safe_params = {k: v for k, v in params.items() if k != "signature"}
        log.info("POST %s params=%s", url, safe_params)

        try:
            resp = self._session.post(
                url,
                data=params,
                headers=self._headers(),
                timeout=REQUEST_TIMEOUT,
            )
        except requests.exceptions.Timeout as exc:
            log.error("POST %s timed out: %s", url, exc)
            raise BinanceNetworkError(f"Request timed out: {exc}") from exc
        except requests.exceptions.ConnectionError as exc:
            log.error("POST %s connection error: %s", url, exc)
            raise BinanceNetworkError(f"Connection error: {exc}") from exc

        return self._handle_response(resp)

    def delete(self, path: str, params: Optional[dict] = None) -> Any:
        """Send a signed DELETE request."""
        params = params or {}
        params["timestamp"] = self._timestamp()
        params["recvWindow"] = self.recv_window
        params["signature"] = self._sign(params)

        url = f"{self.base_url}{path}"
        log.info("DELETE %s params=%s", url, {k: v for k, v in params.items() if k != "signature"})

        try:
            resp = self._session.delete(
                url, params=params, headers=self._headers(), timeout=REQUEST_TIMEOUT
            )
        except requests.exceptions.Timeout as exc:
            log.error("DELETE %s timed out: %s", url, exc)
            raise BinanceNetworkError(f"Request timed out: {exc}") from exc
        except requests.exceptions.ConnectionError as exc:
            log.error("DELETE %s connection error: %s", url, exc)
            raise BinanceNetworkError(f"Connection error: {exc}") from exc

        return self._handle_response(resp)

    # ── Convenience wrappers ──────────────────────────────────────────────────

    def ping(self) -> bool:
        """Return True if the testnet is reachable."""
        try:
            self.get("/fapi/v1/ping")
            log.info("Testnet ping OK")
            return True
        except BinanceClientError as exc:
            log.error("Testnet ping failed: %s", exc)
            return False

    def get_account(self) -> dict:
        """Fetch USDT-M futures account information."""
        return self.get("/fapi/v2/account", signed=True)

    def get_exchange_info(self) -> dict:
        """Fetch exchange trading rules and symbol information."""
        return self.get("/fapi/v1/exchangeInfo")

    def get_open_orders(self, symbol: Optional[str] = None) -> list:
        """Fetch all open orders, optionally filtered by symbol."""
        params = {}
        if symbol:
            params["symbol"] = symbol
        return self.get("/fapi/v1/openOrders", params=params, signed=True)

    def cancel_order(self, symbol: str, order_id: int) -> dict:
        """Cancel an existing open order by orderId."""
        return self.delete(
            "/fapi/v1/order",
            params={"symbol": symbol, "orderId": order_id},
        )
